package com.example.eudeka_comp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
